package com.example.hito1android

data class Producto(
    var codigo:Int,
    var nombre:String,
    var unidades:Int
)
